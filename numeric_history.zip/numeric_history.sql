-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 12 oct. 2021 à 15:10
-- Version du serveur : 10.4.20-MariaDB
-- Version de PHP : 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `numeric_history`
--

-- --------------------------------------------------------

--
-- Structure de la table `personnages`
--

CREATE TABLE `personnages` (
  `id` int(11) NOT NULL,
  `nom_complet` varchar(55) NOT NULL,
  `nom_image` varchar(255) NOT NULL,
  `historique` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `personnages`
--

INSERT INTO `personnages` (`id`, `nom_complet`, `nom_image`, `historique`) VALUES
(1, 'Bill GATES', 'img/bill.jpg', 'Grand mathématicien de l’Antiquité grecque dont la vie nous est très peu connue, Euclide est l’auteur du premier véritable livre de mathématiques de l’histoire, Les éléments. Il y décrit l’un des plus vieux algorithmes encore utilisés aujourd’hui : l’algorithme d’Euclide. Celui-ci est désormais enseigné au collège, et est utilisé pour l’étude des nombres entiers, l’arithmétique.'),
(2, 'Steve Jobs', 'img/jobs.jpg', 'Sa renommée lui a valu de son vivant d’être convoqué par le calife Al’Mamun. Ce dernier voulait entendre de lui une prédiction sur le temps qui lui restait à vivre. Le savant, fier de cette confiance, prit un ton grave en fermant les yeux et improvisa une réponse : « Je vois, ô Calife, un très long règne. Déjà vingt années passées, encore cinquante à venir. »\r\n\r\nLe Calife Al’Mamun fut ravi. Mais dix jours plus tard, il mourut. Al-Khwârizmî fut ainsi reconnu comme le père des mathématiques, jamais comme prophète.'),
(3, 'Marck ZUCKERBERG', 'img/marck.jpg', 'L’Angleterre du 19e siècle, et surtout les universités victoriennes ont fourni un certain nombre de mathématiciens précurseurs qui ont préparé le monde numérique d’aujourd’hui.\r\n\r\nParmi eux, George Boole, qui a inventé l’algèbre binaire en tentant de rattacher le raisonnement logique aux mathématiques, et non plus à la philosophie. Il voulait ainsi traduire des concepts en formules, leur appliquer certaines lois et ensuite retraduire le résultat en termes logiques. Ainsi, son algèbre n’accepte que deux valeurs numériques : 0 et 1. 1 désigne une proposition vraie, et 0 une proposition fausse. Cette algèbre repose sur trois lois : ET, OU, NON.'),
(4, 'Tim Berners LEE', 'img/lee.jpg', 'Si vous surfez sur le web avec votre ordinateur, c’est grâce à Tim Berners Lee ! Tout commence au Conseil Européen pour la Recherche Nucléaire : le CERN. Le chercheur propose de travailler sur l’amélioration du partage de toutes les informations sur un seul réseau, le but étant de faciliter la communication instantanée autour des travaux des physiciens et leur permettre d’être en permanence en contact entre eux, depuis leurs pays respectifs ou au sein du CERN à Genève.\r\n\r\nAvec ses recherches, Tim Berners Lee tente de réaliser ce vieux rêve de créer un réseau dynamique, constitué par un ensemble de documents informatiques liés entre eux. C’est ce que Ted Nelson aura appelé en 1965 l’Hypertexte, un texte avec des liens permettant facilement d’aller d’une partie à une autre, d’un mot à sa définition, d’un paragraphe à une note, d’une section à une autre. Le Web de Tim Berners Lee c’est tout ça en très simplifié, mais à l’échelle planétaire.'),
(5, 'Elun MUSC', 'img/elon.jpg', 'Elon Reeve Musk FRS est un entrepreneur et un magnat des affaires. Il est le fondateur, PDG et ingénieur en chef de SpaceX ; investisseur en démarrage, PDG et architecte produit de Tesla, Inc. ; fondateur de The Boring Company; et co-fondateur de Neuralink et OpenAI'),
(6, 'Federico FAGGIN', 'img/fred.jpg', 'Physicien italien ayant émigré aux Etats-Unis à la fin des années 60, il a mis au point le premier microprocesseur commercialisé par l’entreprise américaine Intel en 1971, le Intel 4004.\r\n\r\nLe microprocesseur est un composant électronique qui permet aux ordinateurs actuels d’exécuter un programme et de traiter des données. Avant son invention, les ordinateurs devaient être beaucoup plus gros (de la taille d’une pièce de maison) pour pouvoir fonctionner. C’est cette invention qui a ouvert la voie à la diffusion large de l’informatique telle qu’on la connait aujourd’hui, en particulier dans les maisons et les entreprises.'),
(7, 'Frances ALLEN', 'img/allen.jpg', 'L’informaticienne américaine Frances Allen est en 2008 la première femme à obtenir le Prix Turing, l’équivalent pour les informaticiens du Prix Nobel, notamment pour ses travaux sur la compilation. L’opération de compilation d’une suite de 0 et de 1 représentant les instructions écrites par un programmeur en une autre suite de 0 et de 1 représentant des instructions correspondantes en langage machine est une opération complexe. C’est d’autant plus vrai lorsque le programme est long.\r\n\r\nFrances Allen a travaillé dès le début des années 70 sur l’optimisation de la compilation. Son but était de faire en sorte que le résultat d’une compilation donne des instructions en langage machine que l’ordinateur puisse exécuter le plus rapidement possible. Cela permet de soulager les humains qui peuvent ainsi écrire des programmes plus facilement compréhensibles en sachant que le compilateur se chargera de certaines opérations complexes permettant de gagner du temps lorsque le programme est lancé.'),
(8, 'Margaret HAMILTON', 'img/MILTON.jpg', 'Margaret Hamilton s’est très tôt intéressée à l’informatique et aux mathématiques. Après ses études elle devient programmeuse au sein de plusieurs laboratoires, ce qui la conduit finalement à travailler avec la NASA pour le projet Apollo visant à envoyer des hommes sur la Lune. C’est Margaret Hamilton qui était en charge de la conception de tous les logiciels embarqués dans la fusée, elle en écrira d’ailleurs la majorité du code (sur la photo ci-dessous on la voit poser à coté de l’ensemble du code écrit pour la mission).\r\n\r\nMargaret Hamilton a révolutionné l’ingénierie logicielle et la conception de programmes complexes. En effet il est extrêmement difficile de construire des logiciels constitués de plusieurs parties imbriquées, ce qui est le cas des fusées lunaires (le radar, les communications, la gestion des informations fournies par les capteurs, etc. fonctionnent tous en même temps). De plus tous les logiciels comportent forcément quelques bugs non détectés qui peuvent potentiellement poser des problèmes graves s’ils se déclenchent. Margaret Hamilton a pour cela inventé de nouvelles méthodes permettant de limiter la gravité des défaillances informatiques, en laissant la possibilité soit pour les humains de reprendre le contrôle, soit pour l’ordinateur de détecter et d’abandonner uniquement les procédures défectueuses. Ces innovations ont d’ailleurs permis de sauver la mission lorsque le radar du module lunaire a saturé la mémoire de l’ordinateur de bord.');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `personnages`
--
ALTER TABLE `personnages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `personnages`
--
ALTER TABLE `personnages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
